package com.example.demo.services;

import com.example.demo.entity.User;

public interface UserService {
	
	public boolean registerUser(User user);

	User loginUser(String username, String password);
}
