package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepo;
	
	@Override
	public boolean registerUser(User user) {
		try {
		userRepo.save(user);
		return true;
		}catch (Exception e) {
		  return false;
		}
	}
	
	@Override
	public User loginUser (String username, String password) {
		User validateUser=userRepo.findByName(username);
		if(validateUser!=null && validateUser.getPassword().equals(password)) {
			return validateUser;
			
		}
		return null;
	}

}
