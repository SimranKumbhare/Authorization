package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.services.UserService;
import com.example.demo.services.UserServiceImpl;


@Controller
public class UserController {
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	UserService userservice;
	
	@GetMapping("/registerform")
	public String openRegister(Model model) {
		model.addAttribute("user", new User());
		return "register";
		
	}
	
	@GetMapping("/loginform")
	public String openLogin(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}
	
	@PostMapping("/loginform")
	public String submitLoginForm(@ModelAttribute("user") User user, Model model) {
		User validateUser=userservice.loginUser(user.getUsername(), user.getPassword());
		
		if(validateUser!=null) {
			model.addAttribute("modelName", validateUser.getName());
			return "profile";
		}
		else {
			model.addAttribute("error", "Username & Password Does't Match");
			return "login";
		}
	}
	
	@PostMapping("/registerform")
	public String submitform(@ModelAttribute("user") User user, Model model) {
		boolean result=userservice.registerUser(user);
		
		if(result) {
			model.addAttribute("success", "Registered Successfully..");
		}
		else {
			model.addAttribute("error", "Try Again..!!");
		}
		return "register";
	}
}
